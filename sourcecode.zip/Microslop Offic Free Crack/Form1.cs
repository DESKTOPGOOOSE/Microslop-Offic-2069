﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Microslop_Offic_Free_Crack
{
    public partial class Form1 : Form
    {
        private const string V = "c:/windows/system32/slui.exe";
        private const string FileName = V;

        public Form1()
        {
            InitializeComponent();
        }

        public object BM_CLICK { get; private set; }

        private void button1_Click(object sender, EventArgs e)
        {
            object dialogButtonHandle = null;
            SendMessage(dialogButtonHandle, BM_CLICK, 1, 0);
        }

        private void SendMessage(object dialogButtonHandle, object bM_CLICK, int v1, int v2)
        {
            throw new NotImplementedException();
        }
    }
}
